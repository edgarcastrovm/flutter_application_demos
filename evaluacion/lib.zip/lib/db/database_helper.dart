import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/estudiante.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;

  static Database? _database;

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'estudiantes.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE estudiantes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombres TEXT,
            edad INTEGER,
            fecha TEXT,
            pais TEXT,
            ciudad TEXT,
            cuotaInicial REAL,
            cuotaMensual REAL
          )
        ''');
      },
    );
  }

  Future<void> insertarEstudiante(Estudiante estudiante) async {
    final db = await database;
    await db.insert('estudiantes', estudiante.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Estudiante>> obtenerEstudiantes() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('estudiantes');

    return List.generate(maps.length, (i) => Estudiante.fromMap(maps[i]));
  }
}
